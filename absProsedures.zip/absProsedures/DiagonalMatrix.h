#ifndef __DiagonalMatrix__
#define __DiagonalMatrix__

#include <fstream>

// Диагональная матрица на основе одномерного массива (параметры - размер и элементы массива)

struct DiagonalMatrix {
    int size;
    int *array;
};

void Enter(DiagonalMatrix &dm, std::ifstream &enterstr);

void EnterRandom(DiagonalMatrix &dm);

void Print(DiagonalMatrix &dm, std::ofstream &outstr);

double Average(DiagonalMatrix &dm);

#endif //__DiagonalMatrix__