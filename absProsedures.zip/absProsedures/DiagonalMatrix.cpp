
//Файл с реализацией структуры диагональной матрицы

#include "DiagonalMatrix.h"
#include <stdlib.h>

// Ввод вручную
void Enter(DiagonalMatrix &dm, std::ifstream &enterstr) {
    enterstr >> dm.size;
    dm.array = new int [dm.size];
    for (int i = 0; i < dm.size; ++i) {
        enterstr >> dm.array[i];
        // Если мы встретили 0 или конец файла (тоже будет 0), то
        // до заполняем матрицу единицами, чтобы получить диагональную
        if (dm.array[i] == 0) {
            dm.array[i] = 1;
        }
    }
}

// Случайное заполнение матрицы
void EnterRandom(DiagonalMatrix &dm) {
    // Размер от 2 до 11
    dm.size = random() % 10 + 2;
    dm.array = new int[dm.size];
    // Числами до 100
    for (int i = 0; i < dm.size; ++i) {
        dm.array[i] = random() % 100 + 1;
    }
}

// вывод матрицы на экран
void Print(DiagonalMatrix &dm, std::ofstream &outstr) {
    outstr << "This is a diagonal square matrix:\n";
    for (int i = 0; i < dm.size; ++i) {
        for (int j = 0; j < dm.size; ++j) {
            if (i == j) {
                outstr << dm.array[i] << " ";
            } else {
                outstr << "0" << " ";
            }
        }
        outstr << "\n";
    }
    outstr << "An average is " << Average(dm) << "\n";
}

// Подсчет среднего из чисел матрицы
double Average(DiagonalMatrix &dm) {
    double result = 0;
    for (int i = 0; i < dm.size; ++i) {
        for (int j = 0; j < dm.size; ++j) {
            if (i == j) {
                result += dm.array[i];
            }
        }
    }
    return (result / (dm.size * dm.size));
}