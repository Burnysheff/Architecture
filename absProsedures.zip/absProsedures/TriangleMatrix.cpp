
#include "TriangeMatrix.h"
#include <stdlib.h>

// Ввод из файла
void Enter(TriangeMatrix &tm, std::ifstream &enterstr) {
    enterstr >> tm.size >> tm.step;
    tm.array = new int* [tm.size];
    for(int i = 0; i < tm.size; i++) {
        tm.array[i] = new int[tm.size];
    }
    for (int i = 0; i < tm.size; ++i) {
        for (int j = 0; j < tm.size; ++j) {
            if (i == j) {
                enterstr >> tm.array[i][j];
                // Если элемент на диагонали равен 0 (или если закончился файл, что даст
                // тот же результат), то добиваем матрицу единицами
                if (tm.array[i][j] == 0) {
                    tm.array[i][j] = 1;
                }
            } else {
                // Вычисление значения элемента под диагональю
                if (i > j) {
                    tm.array[i][j] = tm.array[j][j] + tm.step * (i - j);
                }
            }
        }
    }
}

// Случайное заполнение
void EnterRandom(TriangeMatrix &tm) {
    tm.size = random() % 10 + 2;
    tm.array = new int* [tm.size];
    for(int i = 0; i < tm.size; i++) {
        tm.array[i] = new int[tm.size];
    }
    for (int i = 0; i < tm.size; ++i) {
        for (int j = 0; j < tm.size; ++j) {
            if (i >= j) {
                tm.array[i][j] = random() % 100;
                // Если число на диагонали и равно 0, то делаем его единицей (чтобы было красиво)
                if (i == j && tm.array[i][j] == 0) {
                    tm.array[i][j] = 1;
                }
            } else {
                tm.array[i][j] = 0;
            }
        }
    }
}

//Вывод на экран
void Print(TriangeMatrix &tm, std::ofstream &outstr) {
    outstr << "This is a triangle matrix:\n";
    for (int i = 0; i < tm.size; ++i) {
        for (int j = 0; j < tm.size; ++j) {
            outstr << tm.array[i][j] << " ";
        }
        outstr << "\n";
    }
    outstr << "An average is " << Average(tm) << "\n";
}

// Вычисление среднего значения
double Average(TriangeMatrix &tm) {
    double result = 0;
    for (int i = 0; i < tm.size; ++i) {
        for (int j = 0; j < tm.size; ++j) {
            result += tm.array[i][j];
        }
    }
    return (result / (tm.size * tm.size));
}