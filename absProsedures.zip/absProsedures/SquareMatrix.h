#ifndef __SquareMatrix__
#define __SquareMatrix__

#include <fstream>

// Структура обычной матрицы - в качестве параметров передаем размер и элементы матрицы

struct SquareMatrix {
    int size;
    int **array;
};

void Enter(SquareMatrix &sq, std::ifstream &enterstr);

void EnterRandom(SquareMatrix &sq);

void Print(SquareMatrix &sq, std::ofstream &outstr);

double Average(SquareMatrix &sq);

#endif //__SquareMatrix__