#ifndef __shape__
#define __shape__

#include <fstream>

#include "SquareMatrix.h"
#include "DiagonalMatrix.h"
#include "TriangeMatrix.h"

// Обобщенная структура матрицы
struct Matrix {
    enum index {Square, Diagonal, Triangle};
    index ind; // ключ, обозначающий, с какой матрицей мы имеем дело
    union {
        SquareMatrix sq;
        DiagonalMatrix dm;
        TriangeMatrix tm;
    };
};

Matrix *Enter(std::ifstream &enterstr);

Matrix *EnterRandom();

void Print(Matrix &m, std::ofstream &outstr);

double Average(Matrix &m);

#endif
