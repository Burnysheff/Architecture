#ifndef __Container__
#define __Container__

#include "Matrix.h"

// Контейнер для хранения матриц

struct Container {
    // Массив указателей на матрицы (максимум 10000)
    Matrix *list[10000];
    // Переменная, показывающая, сколько матриц мы храним
    int length;
};

void Make(Container &cont);

void Enter(Container &cont, std::ifstream &enterstr);

void EnterRandom(Container &cont, int size);

void Print(Container &cont, std::ofstream &outstr);

void Free(Container &c);

double Average(Container &c);

void Sort(Container &c);

#endif
