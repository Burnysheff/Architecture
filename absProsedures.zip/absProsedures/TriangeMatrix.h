#ifndef __TriangeMatrix__
#define __TriangeMatrix__

#include <fstream>

// Нижняя треугольная матрица (на основе одномерного массива);
// Параметры - размер массива, его элементы и шаг (для того, чтобы заполнить элементы под диагональю)
// Элемент [i][j] на (i - j) * step больше элемента на диагонали

struct TriangeMatrix {
    int step;
    int size;
    int **array;
};

void Enter(TriangeMatrix &tm, std::ifstream &enterstr);

void EnterRandom(TriangeMatrix &tm);

void Print(TriangeMatrix &tm, std::ofstream &outstr);

double Average(TriangeMatrix &tm);

#endif //__TriangeMatrix__