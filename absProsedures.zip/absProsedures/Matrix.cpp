
#include "Matrix.h"

// Формирование матрицы из файла
Matrix  *Enter(std::ifstream &enterstr) {
    // Создаем указатель на матрицу
    Matrix *mt;
    int index;
    //  Смотрим на ключ и в зависимости от него формируем ту или иную матрицу
    enterstr >> index;
    switch(index) {
        case 1:
            // Создание матрицы
            mt = new Matrix();
            // Присваивание ключа, указывающего на вид матрицы
            mt->ind = Matrix::Square;
            // Ввод матрицы
            Enter(mt->sq, enterstr);
            return mt;
        case 2:
            mt = new Matrix();
            mt->ind = Matrix::Triangle;
            Enter(mt->tm, enterstr);
            return mt;
        case 3:
            mt = new Matrix();
            mt->ind = Matrix::Diagonal;
            Enter(mt->dm, enterstr);
            return mt;
        default:
            return 0;
    }
}

//Случайное формирование матрицы
Matrix *EnterRandom() {
    Matrix *mt;
    // Случайны образом выбираем какой будет наша матрица
    int k = rand() % 3 + 1;
    switch(k) {
        case 1:
            mt = new Matrix();
            mt->ind = Matrix::Square;
            EnterRandom(mt->sq);
            return mt;
        case 2:
            mt = new Matrix();
            mt->ind = Matrix::Diagonal;
            EnterRandom(mt->dm);
            return mt;
        case 3:
            mt = new Matrix();
            mt->ind = Matrix::Triangle;
            EnterRandom(mt->tm);
            return mt;
    }
}

// Вывод матрицы на экран
void Print(Matrix &mt, std::ofstream &outstr) {
    // Смотрим, какого вида наша матрица и запускаем функцию вывода
    switch(mt.ind) {
        case Matrix::Square:
            Print(mt.sq, outstr);
            break;
        case Matrix::Diagonal:
            Print(mt.dm, outstr);
            break;
        case Matrix::Triangle:
            Print(mt.tm, outstr);
            break;
    }
}

// Вычисление среднего значения для матрицы
double Average(Matrix &mt) {
    // Запускаем функции в зависимости от вида матрицы
    switch(mt.ind) {
        case Matrix::Square:
            return Average(mt.sq);
        case Matrix::Diagonal:
            return Average(mt.dm);
        case Matrix::Triangle:
            return Average(mt.tm);
    }
}