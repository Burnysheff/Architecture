
#include "SquareMatrix.h"
#include <stdlib.h>

// Ввод из файла
void Enter(SquareMatrix &sq, std::ifstream &enterstr) {
    enterstr >> sq.size;
    sq.array = new int* [sq.size];
    for(int i = 0; i < sq.size; i++) {
        sq.array[i] = new int[sq.size];
    }
    for (int i = 0; i < sq.size; ++i) {
        for (int j = 0; j < sq.size; ++j) {
            enterstr >> sq.array[i][j];
            if (sq.array[i][j] == 0) {
                sq.array[i][j] = 1;
            }
        }
    }
}

// Случайное формирование элементов
void EnterRandom(SquareMatrix &sq) {
    sq.size = random() % 10 + 2;
    sq.array = new int* [sq.size];
    for(int i = 0; i < sq.size; i++) {
        sq.array[i] = new int[sq.size];
    }
    for (int i = 0; i < sq.size; ++i) {
        for (int j = 0; j < sq.size; ++j) {
            sq.array[i][j] = random() % 100;
        }
    }
}

// Вывод матрицы на экран
void Print(SquareMatrix &sq, std::ofstream &outstr) {
    outstr << "This is an ordinary square matrix:\n";
    for (int i = 0; i < sq.size; ++i) {
        for (int j = 0; j < sq.size; ++j) {
            outstr << sq.array[i][j] << " ";
        }
        outstr << "\n";
    }
    outstr << "An average is " << Average(sq) << "\n";
}

// Подсчет среднего значения
double Average(SquareMatrix &sq) {
    double result = 0;
    for (int i = 0; i < sq.size; ++i) {
        for (int j = 0; j < sq.size; ++j) {
            result += sq.array[i][j];
        }
    }
    return (result / (sq.size * sq.size));
}