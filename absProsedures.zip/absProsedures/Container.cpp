#include "Container.h"

// Создание контейнера (без элементов)
void Make(Container &cont) {
    cont.length = 0;
}

// ввод содержимого контейнера из файла
void Enter(Container &cont, std::ifstream &enterstr) {
    while (!enterstr.eof()) {
        // Если мы уже храним 9999 элементов, то прекращаем считывание
        if (cont.length == 9999) {
            break;
        }
        // Пустой указатель на матрицу, куда и будем записывать создаваемый элемент
        Matrix *mat;
        mat = Enter(enterstr);
        // Если элемент не пустой (данные в файле нормальные), то добавляем в контейнер
        if (mat != 0) {
            cont.list[cont.length] = mat;
            ++cont.length;
        }
    }
}

// Случайный ввод содержимого контейнера
void EnterRandom(Container &cont, int size) {
    for (int i = 0; i < size; ++i) {
        cont.list[cont.length] = EnterRandom();
        ++cont.length;
    }
}

// вывод контейнера на экран
void Print(Container &cont, std::ofstream &outstr) {
    outstr << "Totally " << cont.length << " elements" << std::endl;
    for (int i = 0; i < cont.length; ++i) {
        outstr << "\nElement №" << i + 1 << "\n";
        Print(*(cont.list[i]), outstr);
    }
}

// Удаление всех данных из контейнера (чисти память)
void Free(Container &cont) {
    for (int i = 0; i < cont.length; ++i) {
        delete(cont.list[i]);
    }
    cont.length = 0;
}

// Вычисление среднего значения для всех матриц
double Average(Container &cont) {
    double result;
    for (int i = 0; i < cont.length; ++i) {
        result += Average(*(cont.list[i]));
    }
    return result / cont.length;
}

// Сортировка матриц пузырьком по среднему значению элементов матрицы
void Sort(Container &cont) {
    for (int i = 0; i < cont.length; ++i) {
        for (int j = 0; j < cont.length - 1; ++j) {
            if (Average(*(cont.list[j])) > Average(*(cont.list[j + 1]))) {
                Matrix *mat = cont.list[j + 1];
                cont.list[j + 1] = cont.list[j];
                cont.list[j] = mat;
            }
        }
    }
}